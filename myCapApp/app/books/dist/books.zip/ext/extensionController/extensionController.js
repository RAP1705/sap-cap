sap.ui.define(["sap/m/MessageToast"],function(n){"use strict";return{sampleFunction:function(s){n.show("Custom handler invoked.")}}});
//# sourceMappingURL=extensionController.js.map